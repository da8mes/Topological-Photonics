% a set of general parameters describing the apparatus/universe

Kappa = 1.6; % MHz, Cavity Linewidth
GammaP= 6.0; % MHz, p-state linewidth